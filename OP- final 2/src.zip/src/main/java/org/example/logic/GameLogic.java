package org.example.logic;

import java.awt.*;
import java.util.ArrayList;

public class GameLogic {
    private Player player;
    private Enemy enemy;
    private ArrayList<Wall> walls;

    private final int ENEMY_STEPS = 5;
    private final int PLAYER_STEPS = 20;

    private boolean gameOver = false;

    public GameLogic() {
        this.player = null;
        this.enemy = null;
        this.walls = new ArrayList<>();
    }

    public void initialize() {
        player = new Player(20, 20, "penelope.png");
        enemy = new Enemy(350, 350, "colin.png", 100);
        gameOver = false;  // Reset game over state
        // Initialize walls or other game elements if needed
    }

    public void update() {
        if (gameOver) return;  // Stop updating if game is over

        if (enemy != null) {
            int differenceX = Math.abs(player.getCoord().x - enemy.getCoord().x);
            int differenceY = Math.abs(player.getCoord().y - enemy.getCoord().y);
            boolean isEnemyCollided = enemy.isEnemyCollided(walls);

            if (differenceX > differenceY) {
                if (player.getCoord().x - enemy.getCoord().x > 0 || isEnemyCollided) {
                    enemy.move(ENEMY_STEPS, Direction.RIGHT);
                } else {
                    enemy.move(ENEMY_STEPS, Direction.LEFT);
                }
            } else {
                if (player.getCoord().y - enemy.getCoord().y > 0 || isEnemyCollided) {
                    enemy.move(ENEMY_STEPS, Direction.DOWN);
                } else {
                    enemy.move(ENEMY_STEPS, Direction.UP);
                }
            }

            for (Wall wall : walls) {
                if (player.isCollided(wall.getRectangle())) {
                    wall.inactivate();
                }
            }

            if (player.isCollided(enemy.getRectangle())) {
                gameOver = true;
                // Trigger game over logic
            }
        }
    }

    public boolean predictCollision(Direction direction) {
        if (gameOver) return false;  // Prevent collision checks if game is over

        Rectangle moveRectangle = new Rectangle();
        switch (direction) {
            case RIGHT -> moveRectangle = new Rectangle(player.getX() + PLAYER_STEPS, player.getY(), player.getWidth(), player.getHeight());
            case LEFT -> moveRectangle = new Rectangle(player.getX() - PLAYER_STEPS, player.getY(), player.getWidth(), player.getHeight());
            case UP -> moveRectangle = new Rectangle(player.getX(), player.getY() - PLAYER_STEPS, player.getWidth(), player.getHeight());
            case DOWN -> moveRectangle = new Rectangle(player.getX(), player.getY() + PLAYER_STEPS, player.getWidth(), player.getHeight());
        }
        for (Wall wall : walls) {
            if (moveRectangle.intersects(wall.getRectangle())) {
                return true;
            }
        }
        return false;
    }

    public void movePlayer(Direction direction) {
        if (!gameOver) {
            player.move(PLAYER_STEPS, direction);
        }
    }

    public Enemy getEnemy() {
        return enemy;
    }

    public Player getPlayer() {
        return player;
    }

    public ArrayList<Wall> getWalls() {
        return walls;
    }

    public boolean isGameOver() {
        return gameOver;
    }
}


