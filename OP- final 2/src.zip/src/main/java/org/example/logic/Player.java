package org.example.logic;

import javax.swing.*;
import java.awt.*;

public class Player {
    private Point coord;
    private Image image;
    private int width;
    private int height;

    public Player(int x, int y, String imagePath) {
        this.coord = new Point(x, y);
        this.image = new ImageIcon(imagePath).getImage();
        this.width = image.getWidth(null);
        this.height = image.getHeight(null);
    }

    public Point getCoord() {
        return coord;
    }

    public Image getImage() {
        return image;
    }

    public void move(int steps, Direction direction) {
        switch (direction) {
            case UP -> coord.y -= steps;
            case DOWN -> coord.y += steps;
            case LEFT -> coord.x -= steps;
            case RIGHT -> coord.x += steps;
        }
    }

    public boolean isCollided(Point itemCoord) {
        Rectangle playerRect = new Rectangle(coord.x, coord.y, width, height);
        Rectangle itemRect = new Rectangle(itemCoord.x, itemCoord.y, width, height);
        return playerRect.intersects(itemRect);
    }
}
