package org.example.logic;

public enum Direction {
    UP, LEFT, RIGHT, DOWN
}
