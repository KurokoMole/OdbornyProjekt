package org.example;

import org.example.logic.Direction;
import org.example.logic.GameLogic;

import javax.swing.*;
import java.awt.event.*;

public class Game {
    private GameLogic logic;
    private GameGraphics graphic;
    private GameMenu menu;
    private Timer gameTimer;
    private boolean paused;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Game());
    }

    public Game() {
        logic = new GameLogic();
        graphic = new GameGraphics(logic);
        menu = new GameMenu(this);
        paused = false;

        logic.initialize();
        graphic.render(logic);

        graphic.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT -> controlledMove(Direction.LEFT);
                    case KeyEvent.VK_RIGHT -> controlledMove(Direction.RIGHT);
                    case KeyEvent.VK_UP -> controlledMove(Direction.UP);
                    case KeyEvent.VK_DOWN -> controlledMove(Direction.DOWN);
                    case KeyEvent.VK_SPACE -> togglePause();  // Handle spacebar press to pause the game
                }
            }

            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyReleased(KeyEvent e) {}
        });

        graphic.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int differenceX = e.getX() - logic.getPlayer().getX();
                int differenceY = e.getY() - logic.getPlayer().getY() - graphic.getInsets().top;
                if (differenceX > 0 && differenceX < logic.getPlayer().getWidth() &&
                        differenceY > 0 && differenceY < logic.getPlayer().getHeight()) {
                    logic.movePlayer(Direction.RIGHT);
                }
            }
        });

        gameTimer = new Timer(100, e -> {
            if (!paused) {
                logic.update();
                graphic.render(logic);
                if (logic.isGameOver()) {
                    gameTimer.stop(); // Stop the game when it's over
                    graphic.showGameOver(); // Display game over message
                    menu.showMenu();  // Show menu when game is over
                }
            }
        });

        gameTimer.start();
    }

    private void controlledMove(Direction direction) {
        if (!logic.predictCollision(direction) && !logic.isGameOver() && !paused) {
            logic.movePlayer(direction);
        }
    }

    private void togglePause() {
        paused = !paused;
        if (paused) {
            gameTimer.stop();
            graphic.showPauseMessage(); // Display pause message
        } else {
            gameTimer.start();
            graphic.hidePauseMessage(); // Hide pause message
        }
    }

    public void startNewGame() {
        logic = new GameLogic();
        logic.initialize();
        graphic.render(logic);
        menu.showMenu();  // Hide menu when starting new game
        paused = false;
        gameTimer.start(); // Restart the timer for the new game
    }

    public GameLogic getLogic() {
        return logic;
    }
}
