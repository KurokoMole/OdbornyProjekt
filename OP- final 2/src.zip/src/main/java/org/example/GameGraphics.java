package org.example;

import org.example.logic.*;

import javax.swing.*;
import java.awt.*;

public class GameGraphics extends JFrame {
    private Draw draw;
    private GameLogic logic;
    private Background background;
    private boolean showGameOver;
    private boolean showPause;

    public GameGraphics(GameLogic logic) throws HeadlessException {
        this.logic = logic;
        this.background = new Background("background.png");
        this.draw = new Draw();

        setSize(1920, 1080);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setTitle("Bridgerton Game");

        add(draw);
        showGameOver = false;
        showPause = false;
    }

    public void render(GameLogic logic) {
        this.logic = logic;
        repaint();
    }

    public void showGameOver() {
        showGameOver = true;
        repaint();
    }

    public void showPauseMessage() {
        showPause = true;
        repaint();
    }

    public void hidePauseMessage() {
        showPause = false;
        repaint();
    }

    public class Draw extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Draw the background
            background.draw(g, this);

            // Draw the player
            g.drawImage(logic.getPlayer().getImage(), logic.getPlayer().getX(), logic.getPlayer().getY(), this);

            // Draw the walls
            for (Wall wall : logic.getWalls()) {
                if (wall.isActive()) {
                    g.setColor(wall.getColor());
                    g.drawLine(wall.getCoordStart().x, wall.getCoordStart().y, wall.getCoordEnd().x, wall.getCoordEnd().y);
                }
            }

            // Draw the enemy
            Enemy enemy = logic.getEnemy();
            g.drawImage(enemy.getImage(), enemy.getCoord().x, enemy.getCoord().y, this);

            // Draw "Game Over" text if the game is over
            if (showGameOver) {
                g.setFont(new Font("Arial", Font.BOLD, 72));
                g.setColor(Color.RED);
                g.drawString("GAME OVER", getWidth() / 2 - 200, getHeight() / 2);
            }

            // Draw "Paused" text if the game is paused
            if (showPause) {
                g.setFont(new Font("Arial", Font.BOLD, 72));
                g.setColor(Color.YELLOW);
                g.drawString("PAUSED", getWidth() / 2 - 150, getHeight() / 2);
            }
        }
    }
}
