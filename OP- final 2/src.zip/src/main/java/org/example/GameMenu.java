package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameMenu {
    private JFrame menuFrame;
    private final Game game;

    public GameMenu(Game game) {
        this.game = game;
        createMenu();
    }

    private void createMenu() {
        menuFrame = new JFrame("Game Menu");
        menuFrame.setSize(400, 300);
        menuFrame.setLocationRelativeTo(null);
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1)); // Arrange buttons vertically
        menuFrame.add(panel);

        JButton startButton = new JButton("Start New Game");
        JButton helpButton = new JButton("Help");
        JButton exitButton = new JButton("Exit");

        panel.add(startButton);
        panel.add(helpButton);
        panel.add(exitButton);

        startButton.addActionListener(e -> {
            menuFrame.setVisible(false);
            game.startNewGame();
        });

        helpButton.addActionListener(e -> showHelp());

        exitButton.addActionListener(e -> System.exit(0));

        menuFrame.setVisible(true);
    }

    private void showHelp() {
        JOptionPane.showMessageDialog(menuFrame, "Your help text goes here.\n" +
                        "Describe how to play the game, controls, objectives, etc.",
                "Help", JOptionPane.INFORMATION_MESSAGE);
    }

    public void showMenu() {
        menuFrame.setVisible(true);
    }
}
