package org.example;

import javax.swing.*;
import java.awt.*;

public class Background {
    private Image image;

    public Background(String imagePath) {
        this.image = new ImageIcon(getClass().getResource("/" + imagePath)).getImage();
    }

    public void draw(Graphics g, JPanel panel) {
        g.drawImage(image, 0, 0, panel.getWidth(), panel.getHeight(), panel);
    }
}
